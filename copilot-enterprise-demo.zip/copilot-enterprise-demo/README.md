# GitHub Copilot SDK — Enterprise Java Integration

Full end-to-end Java project for calling GitHub Copilot at runtime,
with complete support for **Standard**, **EMU**, and **GHE** enterprise accounts.

---

## 📁 Project Structure

```
copilot-enterprise-demo/
├── pom.xml
├── README.md
└── src/main/
    ├── java/com/example/copilot/
    │   ├── Main.java                         ← Entry point (5 examples)
    │   ├── config/
    │   │   ├── AccountType.java              ← STANDARD | EMU | GHE enum
    │   │   └── EnterpriseConfig.java         ← Loads copilot.properties + env vars
    │   ├── auth/
    │   │   └── CopilotAuthenticator.java     ← Pre-flight checks + auth guidance
    │   ├── service/
    │   │   ├── CopilotService.java           ← Main service (all 4 send methods)
    │   │   └── CopilotResponse.java          ← Response wrapper with token metrics
    │   └── util/
    │       └── ConsoleUtil.java              ← Console formatting helpers
    └── resources/
        └── copilot.properties                ← ⭐ YOUR CONFIG FILE (edit this first)
```

---

## ✅ Prerequisites

| Requirement | Version | Check |
|---|---|---|
| Java | 17+ | `java -version` |
| Maven | 3.8+ | `mvn -version` |
| Node.js | 18+ | `node -version` |
| GitHub CLI | Latest | `gh --version` |
| Copilot CLI | 1.0.17+ | `copilot --version` |

### Install GitHub CLI
```bash
# macOS
brew install gh

# Windows
winget install --id GitHub.cli

# Ubuntu/Debian
sudo apt install gh
```

### Install Copilot CLI
```bash
npm install -g @github/copilot-cli@latest
```

---

## ⚙️ Step 1 — Configure `copilot.properties`

Edit `src/main/resources/copilot.properties` to match your account type:

### For Standard github.com accounts:
```properties
copilot.account.type=STANDARD
copilot.model=gpt-4.1
```

### For Enterprise Managed Users (EMU) on github.com:
```properties
copilot.account.type=EMU
copilot.model=gpt-4.1
```

### For GitHub Enterprise Cloud with Data Residency (ghe.com):
```properties
copilot.account.type=GHE
copilot.enterprise.host=YOUR-COMPANY.ghe.com
copilot.model=gpt-4.1
```

---

## 🔐 Step 2 — Authenticate the CLI

### STANDARD account
```bash
copilot login
# Follow browser prompts with your personal GitHub account
```

### EMU account (Enterprise Managed Users)
```bash
copilot login
# IMPORTANT: Use your COMPANY SSO login in the browser,
# NOT your personal GitHub account.
# Your username will look like: firstname_companycode
```

Verify it worked:
```bash
copilot /user
# Should show your managed account username
```

### GHE account (ghe.com / Data Residency)
```bash
copilot login --host YOUR-COMPANY.ghe.com
# Complete your SSO flow in the browser
```

Also set the environment variable (required for GHE):
```bash
# Linux / macOS
export COPILOT_GH_HOST=YOUR-COMPANY.ghe.com

# Windows Command Prompt
set COPILOT_GH_HOST=YOUR-COMPANY.ghe.com

# Windows PowerShell
$env:COPILOT_GH_HOST="YOUR-COMPANY.ghe.com"
```

---

## 🚀 Step 3 — Build & Run

```bash
# Build the fat JAR
mvn clean package

# Run the demo
java -jar target/copilot-enterprise-demo-1.0.0.jar
```

For GHE accounts, run with the host env variable:
```bash
COPILOT_GH_HOST=your-company.ghe.com java -jar target/copilot-enterprise-demo-1.0.0.jar
```

---

## 🧪 What the 5 Examples Do

| # | Method | Description | Best For |
|---|---|---|---|
| 1 | `sendAndWait()` | Send prompt → wait → get full response | Batch / background jobs |
| 2 | `sendStreaming()` | Tokens stream to stdout in real time | Interactive CLI |
| 3 | `sendWithMetrics()` | Full response + token usage stats | Production cost monitoring |
| 4 | `sendStreamingWithCallback()` | Custom token handler (not stdout) | UI components, WebSockets |
| 5 | Interactive Chat | Multi-turn session (Copilot remembers context) | Chat assistants |

---

## 🖥️ CI/CD Usage (Token-Based Auth)

For automated pipelines (GitHub Actions, Jenkins, etc.):

```bash
# Set token as environment variable (never hardcode in source)
export COPILOT_GITHUB_TOKEN=gho_xxxxxxxxxxxxxxxxxxxx

java -jar target/copilot-enterprise-demo-1.0.0.jar
```

Or in GitHub Actions:
```yaml
- name: Run Copilot Demo
  env:
    COPILOT_GITHUB_TOKEN: ${{ secrets.COPILOT_TOKEN }}
    COPILOT_GH_HOST: your-company.ghe.com   # GHE only
  run: java -jar target/copilot-enterprise-demo-1.0.0.jar
```

---

## 🔧 Environment Variable Overrides

Any property in `copilot.properties` can be overridden at runtime:

| Env Variable | Overrides | Example |
|---|---|---|
| `COPILOT_ACCOUNT_TYPE` | `copilot.account.type` | `EMU` |
| `COPILOT_ENTERPRISE_HOST` | `copilot.enterprise.host` | `octocorp.ghe.com` |
| `COPILOT_GITHUB_TOKEN` | `copilot.github.token` | `gho_xxx` |
| `COPILOT_MODEL` | `copilot.model` | `claude-sonnet-4.5` |
| `COPILOT_GH_HOST` | CLI host routing (GHE) | `octocorp.ghe.com` |

---

## 🚫 EMU Checklist (if auth fails)

```
✅ Logging in with your MANAGED account (not personal)
✅ Your username looks like: firstname_companycode
✅ Copilot seat is assigned to your managed account
✅ Enterprise admin has NOT disabled Copilot CLI
✅ Corporate VPN / network connected (if required)
✅ SSO session not expired (re-run `copilot login` if needed)
```

---

## 🛑 Troubleshooting

| Error | Solution |
|---|---|
| `Copilot CLI not found` | `npm install -g @github/copilot-cli@latest` |
| `No credentials found (EMU)` | Run `copilot login` via your SSO (not personal account) |
| `No credentials found (GHE)` | Run `copilot login --host YOUR.ghe.com` |
| `CONFIG ERROR: GHE host not set` | Set `copilot.enterprise.host` in copilot.properties |
| `Session timed out` | Increase `copilot.timeout.seconds` in copilot.properties |
| `Invalid account type` | Set `copilot.account.type` to `STANDARD`, `EMU`, or `GHE` |
| `Seat not assigned` | Contact your GitHub Enterprise admin |

---

## 💰 Billing Note

Each call to `sendAndWait`, `sendStreaming`, or `sendWithMetrics`
counts as one **premium request** against your Copilot subscription quota.
Use `sendWithMetrics()` in production to monitor token consumption.
