package com.example.copilot;

import com.example.copilot.config.EnterpriseConfig;
import com.example.copilot.service.CopilotResponse;
import com.example.copilot.service.CopilotService;
import com.example.copilot.util.ConsoleUtil;

import java.util.Scanner;

/**
 * ============================================================
 *  Main — GitHub Copilot SDK Enterprise Java Demo
 *
 *  Demonstrates 5 real-world usage patterns, all working with:
 *    • Standard github.com accounts
 *    • Enterprise Managed Users (EMU)
 *    • GitHub Enterprise Cloud on ghe.com (Data Residency)
 *
 *  BEFORE RUNNING — configure copilot.properties:
 *    1. Set copilot.account.type  (STANDARD | EMU | GHE)
 *    2. If GHE: set copilot.enterprise.host
 *    3. Authenticate the CLI (see README.md)
 *    4. mvn clean package
 *    5. java -jar target/copilot-enterprise-demo-1.0.0.jar
 * ============================================================
 */
public class Main {

    public static void main(String[] args) {
        // ------------------------------------------------
        // Print startup banner
        // ------------------------------------------------
        System.out.println();
        System.out.println("╔══════════════════════════════════════════════════════════╗");
        System.out.println("║   GitHub Copilot SDK — Enterprise Java Integration Demo  ║");
        System.out.println("║   Supports: STANDARD | EMU | GHE (Data Residency)        ║");
        System.out.println("╚══════════════════════════════════════════════════════════╝");
        System.out.println();

        // ------------------------------------------------
        // Load enterprise configuration
        // ------------------------------------------------
        EnterpriseConfig config;
        try {
            config = new EnterpriseConfig();
        } catch (IllegalStateException e) {
            System.err.println("\n" + e.getMessage());
            System.exit(1);
            return;
        }

        // ------------------------------------------------
        // Run examples
        // ------------------------------------------------
        try {
            runExample1_SimpleQA(config);
            runExample2_Streaming(config);
            runExample3_Metrics(config);
            runExample4_Callback(config);
            runExample5_InteractiveChat(config);

        } catch (IllegalStateException e) {
            // Auth / config errors — already have a nice message
            System.err.println("\n" + e.getMessage());
            System.exit(1);

        } catch (Exception e) {
            System.err.println("\n❌ Unexpected error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }

        System.out.println("\n🎉 Demo complete!");
    }

    // ============================================================
    //  EXAMPLE 1 — Simple Q&A (sendAndWait)
    //
    //  Sends a single question and prints the full response once
    //  Copilot has finished generating it. Best for background jobs,
    //  batch processing, or when latency doesn't matter.
    // ============================================================
    static void runExample1_SimpleQA(EnterpriseConfig config) throws Exception {
        ConsoleUtil.printHeader("Example 1 — Simple Q&A (sendAndWait)");

        try (var copilot = new CopilotService(config)) {
            copilot.start();

            String prompt = "Explain Java's try-with-resources in 3 sentences.";
            System.out.println("📤 Prompt: " + prompt + "\n");

            CopilotResponse response = copilot.sendAndWait(prompt);

            System.out.println("🤖 Copilot Response:");
            ConsoleUtil.printDivider();
            System.out.println(response.getContent());
            ConsoleUtil.printDivider();
        }

        ConsoleUtil.pause(1500);
    }

    // ============================================================
    //  EXAMPLE 2 — Streaming Response
    //
    //  Tokens stream to stdout in real time as Copilot generates them.
    //  Best for interactive terminals, chat UIs, and live feedback.
    // ============================================================
    static void runExample2_Streaming(EnterpriseConfig config) throws Exception {
        ConsoleUtil.printHeader("Example 2 — Streaming Response");

        try (var copilot = new CopilotService(config)) {
            copilot.start();

            String prompt = "Write a Java utility method that checks if a string is a valid email address.";
            System.out.println("📤 Prompt: " + prompt + "\n");
            System.out.println("🤖 Copilot (streaming token by token):");
            ConsoleUtil.printDivider();

            copilot.sendStreaming(prompt);

            ConsoleUtil.printDivider();
        }

        ConsoleUtil.pause(1500);
    }

    // ============================================================
    //  EXAMPLE 3 — Response + Token Usage Metrics
    //
    //  Returns the full response AND captures token usage stats.
    //  Essential for production cost monitoring and quota management —
    //  especially important for enterprise accounts billed per request.
    // ============================================================
    static void runExample3_Metrics(EnterpriseConfig config) throws Exception {
        ConsoleUtil.printHeader("Example 3 — Response + Token Usage Metrics");

        try (var copilot = new CopilotService(config)) {
            copilot.start();

            String prompt = "List 5 Java best practices for writing clean, readable code.";
            System.out.println("📤 Prompt: " + prompt + "\n");

            CopilotResponse response = copilot.sendWithMetrics(prompt);

            System.out.println("🤖 Copilot Response:");
            ConsoleUtil.printDivider();
            System.out.println(response.getContent());
            ConsoleUtil.printDivider();

            // Print token usage — critical for enterprise billing awareness
            ConsoleUtil.printUsageMetrics(response);
        }

        ConsoleUtil.pause(1500);
    }

    // ============================================================
    //  EXAMPLE 4 — Streaming with Custom Callback
    //
    //  Instead of printing to stdout, each token chunk is routed to
    //  your custom handler (e.g. a StringBuilder, a UI component,
    //  a REST response stream, a log file, etc.)
    // ============================================================
    static void runExample4_Callback(EnterpriseConfig config) throws Exception {
        ConsoleUtil.printHeader("Example 4 — Streaming with Custom Callback Handler");

        try (var copilot = new CopilotService(config)) {
            copilot.start();

            String prompt = "What is the difference between HashMap and ConcurrentHashMap in Java?";
            System.out.println("📤 Prompt: " + prompt + "\n");

            // Collect all tokens into a StringBuilder (simulating a UI buffer)
            StringBuilder buffer = new StringBuilder();

            System.out.println("🤖 Copilot (buffering via callback — silent stream)...");
            copilot.sendStreamingWithCallback(prompt, token -> {
                buffer.append(token);
                // In a real UI: update a JTextArea, send via WebSocket, etc.
            });

            // Now use the fully buffered result
            System.out.println("\n📦 Buffered response assembled (" + buffer.length() + " chars):");
            ConsoleUtil.printDivider();
            System.out.println(buffer.toString().trim());
            ConsoleUtil.printDivider();
        }

        ConsoleUtil.pause(1500);
    }

    // ============================================================
    //  EXAMPLE 5 — Interactive Multi-turn Chat
    //
    //  The session stays alive across all messages, so Copilot
    //  remembers the full conversation context — just like Copilot Chat.
    //  Each new message builds on everything said before.
    // ============================================================
    static void runExample5_InteractiveChat(EnterpriseConfig config) throws Exception {
        ConsoleUtil.printHeader("Example 5 — Interactive Multi-turn Chat (type 'exit' to quit)");

        Scanner scanner = new Scanner(System.in);

        try (var copilot = new CopilotService(config)) {
            copilot.start();

            System.out.println("💬 Multi-turn chat — session retains full context.");
            System.out.println("   Try: tell Copilot your name, then ask 'what is my name?'");
            System.out.println("   Type 'exit' or 'quit' to end the session.\n");

            int turn = 1;
            while (true) {
                System.out.printf("You [turn %d] > ", turn);
                String input = scanner.nextLine().trim();

                if (input.equalsIgnoreCase("exit") || input.equalsIgnoreCase("quit")) {
                    System.out.println("\n👋 Ending chat session.");
                    break;
                }

                if (input.isEmpty()) {
                    System.out.println("⚠️  Please enter a message.\n");
                    continue;
                }

                System.out.println("\n🤖 Copilot >");
                ConsoleUtil.printDivider();
                copilot.sendStreaming(input);
                ConsoleUtil.printDivider();
                System.out.println();

                turn++;
            }
        }
    }
}
