package com.example.copilot.auth;

import com.example.copilot.config.AccountType;
import com.example.copilot.config.EnterpriseConfig;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * ============================================================
 *  CopilotAuthenticator
 *
 *  Handles pre-flight authentication checks and setup guidance
 *  for all three GitHub account types:
 *
 *    STANDARD  → github.com personal/org — standard gh auth login
 *    EMU       → Enterprise Managed Users on github.com via SSO
 *    GHE       → GitHub Enterprise Cloud (ghe.com) Data Residency
 *
 *  What this class does:
 *    1. Detects whether the Copilot CLI is installed
 *    2. Detects whether credentials are already stored
 *    3. Provides clear guidance when authentication is missing
 *    4. Sets the correct env variables for the CLI process
 *       (host override for GHE, token injection for CI/CD)
 * ============================================================
 */
public class CopilotAuthenticator {

    private final EnterpriseConfig config;

    public CopilotAuthenticator(EnterpriseConfig config) {
        this.config = config;
    }

    // -------------------------------------------------------
    // Main entry point — called before the SDK client starts
    // -------------------------------------------------------

    /**
     * Performs all pre-flight checks. Throws with actionable guidance
     * if anything is misconfigured.
     */
    public void preflight() {
        System.out.println("🔍 Running pre-flight authentication checks...");
        System.out.println("   Account Type : " + config.getAccountType());

        if (config.getAccountType() == AccountType.GHE) {
            System.out.println("   Enterprise   : " + config.getEnterpriseHost());
        }

        checkCopilotCliInstalled();
        checkCredentials();

        System.out.println("✅ Pre-flight checks passed.\n");
    }

    // -------------------------------------------------------
    // Check 1: Is the Copilot CLI installed?
    // -------------------------------------------------------
    private void checkCopilotCliInstalled() {
        boolean found = isCommandAvailable("copilot");

        if (!found) {
            throw new IllegalStateException(buildCliNotFoundMessage());
        }
        System.out.println("   ✔ Copilot CLI found in PATH");
    }

    // -------------------------------------------------------
    // Check 2: Are credentials available?
    // -------------------------------------------------------
    private void checkCredentials() {
        // If a token was explicitly provided (e.g. CI/CD), trust it
        if (config.hasExplicitToken()) {
            System.out.println("   ✔ Using explicit GitHub token (CI/CD mode)");
            // Inject into env so the CLI picks it up
            injectTokenToEnvironment(config.getGithubToken());
            return;
        }

        // Check if stored credentials exist on disk
        if (hasStoredCredentials()) {
            System.out.println("   ✔ Stored CLI credentials detected");
            return;
        }

        // No credentials — print account-type-specific guidance
        throw new IllegalStateException(buildAuthMissingMessage());
    }

    // -------------------------------------------------------
    // Detect stored credentials from the Copilot CLI settings file
    // -------------------------------------------------------
    private boolean hasStoredCredentials() {
        // Copilot CLI stores auth state in ~/.copilot/settings.json (v1.0.35+)
        Path newSettingsPath = Paths.get(System.getProperty("user.home"), ".copilot", "settings.json");
        if (Files.exists(newSettingsPath)) {
            return true;
        }

        // Older versions stored in ~/.config/copilot/
        Path legacyPath = Paths.get(System.getProperty("user.home"), ".config", "copilot", "apps.json");
        if (Files.exists(legacyPath)) {
            return true;
        }

        // Also check if COPILOT_GITHUB_TOKEN / GH_TOKEN env vars are set at OS level
        String envToken = System.getenv("COPILOT_GITHUB_TOKEN");
        if (envToken != null && !envToken.isBlank()) return true;

        String ghToken = System.getenv("GH_TOKEN");
        if (ghToken != null && !ghToken.isBlank()) return true;

        return false;
    }

    // -------------------------------------------------------
    // Inject token into the process environment
    // -------------------------------------------------------
    private void injectTokenToEnvironment(String token) {
        // NOTE: Java cannot directly modify System.getenv() at runtime.
        // The Copilot SDK/CLI reads COPILOT_GITHUB_TOKEN from the OS-level env.
        // For CI/CD, set this env variable BEFORE launching the JVM process.
        // This method logs guidance for that pattern.
        System.out.println("   ℹ  Token injection: set COPILOT_GITHUB_TOKEN before running this process.");
        System.out.println("      Linux/Mac : export COPILOT_GITHUB_TOKEN=gho_xxxx");
        System.out.println("      Windows   : set COPILOT_GITHUB_TOKEN=gho_xxxx");
    }

    // -------------------------------------------------------
    // Helpers
    // -------------------------------------------------------

    private boolean isCommandAvailable(String command) {
        try {
            String[] cmd = System.getProperty("os.name").toLowerCase().contains("win")
                ? new String[]{"where", command}
                : new String[]{"which", command};

            Process process = new ProcessBuilder(cmd)
                .redirectErrorStream(true)
                .start();

            int exitCode = process.waitFor();
            return exitCode == 0;
        } catch (IOException | InterruptedException e) {
            return false;
        }
    }

    // -------------------------------------------------------
    // User-friendly error messages (account-type-specific)
    // -------------------------------------------------------

    private String buildCliNotFoundMessage() {
        return """
            ╔══════════════════════════════════════════════════════════════╗
            ║  ERROR: GitHub Copilot CLI not found in PATH                ║
            ╠══════════════════════════════════════════════════════════════╣
            ║  Install it with:                                           ║
            ║    npm install -g @github/copilot-cli@latest                ║
            ║                                                             ║
            ║  Then verify:                                               ║
            ║    copilot --version                                        ║
            ╚══════════════════════════════════════════════════════════════╝
            """;
    }

    private String buildAuthMissingMessage() {
        return switch (config.getAccountType()) {

            // --------------------------------------------------
            case STANDARD -> """
                ╔══════════════════════════════════════════════════════════════╗
                ║  ERROR: No Copilot CLI credentials found (STANDARD account) ║
                ╠══════════════════════════════════════════════════════════════╣
                ║  Run this once to authenticate:                             ║
                ║    copilot login                                            ║
                ║                                                             ║
                ║  Or if you have GitHub CLI installed:                       ║
                ║    gh auth login --web                                      ║
                ║                                                             ║
                ║  Then verify: copilot /user                                 ║
                ╚══════════════════════════════════════════════════════════════╝
                """;

            // --------------------------------------------------
            case EMU -> """
                ╔══════════════════════════════════════════════════════════════╗
                ║  ERROR: No Copilot CLI credentials found (EMU account)      ║
                ╠══════════════════════════════════════════════════════════════╣
                ║  For Enterprise Managed Users, authenticate via SSO:        ║
                ║                                                             ║
                ║    Step 1: copilot login                                    ║
                ║            (This opens a browser — use your SSO/IdP login,  ║
                ║             NOT a personal GitHub account)                  ║
                ║                                                             ║
                ║    Step 2: Complete your company's SSO flow in the browser  ║
                ║            (Okta / Entra ID / Ping Identity / etc.)         ║
                ║                                                             ║
                ║    Step 3: Verify: copilot /user                            ║
                ║            Your username should look like:                  ║
                ║            username_companyshortcode                        ║
                ║                                                             ║
                ║  TIPS:                                                      ║
                ║  • Use your corporate network or VPN if required            ║
                ║  • Do NOT use your personal GitHub account                  ║
                ║  • Ask your GitHub admin if your seat is assigned           ║
                ╚══════════════════════════════════════════════════════════════╝
                """;

            // --------------------------------------------------
            case GHE -> String.format("""
                ╔══════════════════════════════════════════════════════════════╗
                ║  ERROR: No Copilot CLI credentials found (GHE account)      ║
                ╠══════════════════════════════════════════════════════════════╣
                ║  For GitHub Enterprise Cloud (ghe.com / Data Residency):    ║
                ║                                                             ║
                ║    Step 1: copilot login --host %s              ║
                ║                                                             ║
                ║    Step 2: Complete SSO in the browser                      ║
                ║                                                             ║
                ║    Step 3: Verify: copilot /user                            ║
                ║                                                             ║
                ║  If using VS Code, also set in settings.json:               ║
                ║    "github.copilot.advanced": {                             ║
                ║      "authProvider": "github-enterprise"                    ║
                ║    }                                                        ║
                ║    "github-enterprise.uri": "https://%s"     ║
                ╚══════════════════════════════════════════════════════════════╝
                """,
                padRight(config.getEnterpriseHost(), 20),
                padRight(config.getEnterpriseHost(), 20)
            );
        };
    }

    private String padRight(String s, int n) {
        return String.format("%-" + n + "s", s);
    }
}
