package com.example.copilot.config;

/**
 * Represents the type of GitHub account being used.
 *
 * STANDARD  → Regular github.com personal or organisation account.
 * EMU       → Enterprise Managed User on github.com (identity managed by IdP/SSO).
 * GHE       → GitHub Enterprise Cloud with Data Residency hosted on ghe.com.
 */
public enum AccountType {
    STANDARD,
    EMU,
    GHE
}
