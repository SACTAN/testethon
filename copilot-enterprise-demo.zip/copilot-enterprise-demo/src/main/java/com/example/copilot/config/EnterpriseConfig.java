package com.example.copilot.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * ============================================================
 *  EnterpriseConfig
 *
 *  Loads all configuration from copilot.properties (bundled
 *  inside the JAR) and resolves any values that may be
 *  overridden by environment variables.
 *
 *  Environment variable overrides (for CI/CD / Docker):
 *    COPILOT_ACCOUNT_TYPE      → overrides copilot.account.type
 *    COPILOT_ENTERPRISE_HOST   → overrides copilot.enterprise.host
 *    COPILOT_GITHUB_TOKEN      → overrides copilot.github.token
 *    COPILOT_MODEL             → overrides copilot.model
 * ============================================================
 */
public class EnterpriseConfig {

    // -------------------------------------------------------
    // Resolved configuration values (populated in constructor)
    // -------------------------------------------------------
    private final AccountType accountType;
    private final String enterpriseHost;   // e.g. "octocorp.ghe.com" or "" for github.com
    private final String githubToken;      // OAuth token — null means use CLI stored creds
    private final String model;
    private final boolean streaming;
    private final int timeoutSeconds;

    // -------------------------------------------------------
    // Constructor — loads & resolves config
    // -------------------------------------------------------
    public EnterpriseConfig() {
        Properties props = loadProperties();

        // Resolve each field: environment variable takes priority over properties file
        this.accountType    = resolveAccountType(props);
        this.enterpriseHost = resolve("COPILOT_ENTERPRISE_HOST", "copilot.enterprise.host", props, "").trim();
        this.githubToken    = resolve("COPILOT_GITHUB_TOKEN",    "copilot.github.token",    props, null);
        this.model          = resolve("COPILOT_MODEL",           "copilot.model",           props, "gpt-4.1");
        this.streaming      = Boolean.parseBoolean(
                                  resolve(null, "copilot.streaming", props, "true"));
        this.timeoutSeconds = Integer.parseInt(
                                  resolve(null, "copilot.timeout.seconds", props, "60"));

        validate();
    }

    // -------------------------------------------------------
    // Validation — catches misconfiguration early
    // -------------------------------------------------------
    private void validate() {
        if (accountType == AccountType.GHE && (enterpriseHost == null || enterpriseHost.isBlank())) {
            throw new IllegalStateException(
                "[CONFIG ERROR] Account type is GHE but 'copilot.enterprise.host' is not set.\n" +
                "Set it in copilot.properties or via the COPILOT_ENTERPRISE_HOST environment variable.\n" +
                "Example: copilot.enterprise.host=octocorp.ghe.com"
            );
        }
    }

    // -------------------------------------------------------
    // Public accessors
    // -------------------------------------------------------

    public AccountType getAccountType()  { return accountType;    }
    public String getEnterpriseHost()    { return enterpriseHost;  }
    public String getGithubToken()       { return githubToken;     }
    public String getModel()             { return model;           }
    public boolean isStreaming()         { return streaming;       }
    public int getTimeoutSeconds()       { return timeoutSeconds;  }

    /**
     * Returns the full GitHub base URL for this configuration.
     *   GHE     → https://octocorp.ghe.com
     *   STANDARD/EMU → https://github.com
     */
    public String getGitHubBaseUrl() {
        if (accountType == AccountType.GHE && !enterpriseHost.isBlank()) {
            return "https://" + enterpriseHost;
        }
        return "https://github.com";
    }

    /**
     * Returns true if a token was explicitly provided (useful for CI/CD mode).
     */
    public boolean hasExplicitToken() {
        return githubToken != null && !githubToken.isBlank();
    }

    /** Human-readable summary for startup logging. */
    public String summary() {
        return String.format(
            "Account Type    : %s%n" +
            "Enterprise Host : %s%n" +
            "GitHub Base URL : %s%n" +
            "Model           : %s%n" +
            "Streaming       : %s%n" +
            "Token Source    : %s%n" +
            "Timeout         : %d seconds",
            accountType,
            enterpriseHost.isBlank() ? "(github.com)" : enterpriseHost,
            getGitHubBaseUrl(),
            model,
            streaming,
            hasExplicitToken() ? "Explicit token (env/properties)" : "Stored CLI credentials",
            timeoutSeconds
        );
    }

    // -------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------

    private Properties loadProperties() {
        Properties props = new Properties();
        try (InputStream is = getClass().getClassLoader()
                .getResourceAsStream("copilot.properties")) {
            if (is != null) {
                props.load(is);
            } else {
                System.err.println("[WARN] copilot.properties not found on classpath. Using defaults.");
            }
        } catch (IOException e) {
            System.err.println("[WARN] Failed to load copilot.properties: " + e.getMessage());
        }
        return props;
    }

    private AccountType resolveAccountType(Properties props) {
        String raw = resolve("COPILOT_ACCOUNT_TYPE", "copilot.account.type", props, "STANDARD");
        try {
            return AccountType.valueOf(raw.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalStateException(
                "[CONFIG ERROR] Invalid account type '" + raw + "'. " +
                "Valid values: STANDARD, EMU, GHE"
            );
        }
    }

    /**
     * Resolves a config value: env variable → properties file → default.
     */
    private String resolve(String envKey, String propKey, Properties props, String defaultValue) {
        // 1. Check environment variable first
        if (envKey != null) {
            String envVal = System.getenv(envKey);
            if (envVal != null && !envVal.isBlank()) {
                return envVal.trim();
            }
        }
        // 2. Fall back to properties file
        String propVal = props.getProperty(propKey);
        if (propVal != null && !propVal.isBlank()) {
            return propVal.trim();
        }
        // 3. Use default
        return defaultValue;
    }
}
