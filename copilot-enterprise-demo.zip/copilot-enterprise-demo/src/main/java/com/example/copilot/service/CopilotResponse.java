package com.example.copilot.service;

/**
 * Wraps the response from a Copilot API call.
 * Provides the content text and optional token usage metrics.
 */
public class CopilotResponse {

    private final String content;
    private final int inputTokens;
    private final int totalTokens;
    private final int tokenLimit;
    private final int messageCount;

    public CopilotResponse(String content,
                           int inputTokens,
                           int totalTokens,
                           int tokenLimit,
                           int messageCount) {
        this.content      = content;
        this.inputTokens  = inputTokens;
        this.totalTokens  = totalTokens;
        this.tokenLimit   = tokenLimit;
        this.messageCount = messageCount;
    }

    /** The full text returned by Copilot. */
    public String getContent()    { return content;      }

    /** Number of tokens consumed so far in this session. */
    public int getCurrentTokens() { return inputTokens;  }

    /** Total tokens used (may differ depending on SDK event). */
    public int getTotalTokens()   { return totalTokens;  }

    /** The token limit for this session. */
    public int getTokenLimit()    { return tokenLimit;   }

    /** Number of messages exchanged in this session. */
    public int getMessageCount()  { return messageCount; }

    /** Percentage of token budget consumed (0.0 – 100.0). */
    public double getTokenUsagePercent() {
        if (tokenLimit <= 0) return 0.0;
        return (totalTokens * 100.0) / tokenLimit;
    }

    @Override
    public String toString() {
        return content;
    }
}
