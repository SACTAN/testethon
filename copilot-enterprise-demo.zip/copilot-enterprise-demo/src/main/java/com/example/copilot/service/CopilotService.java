package com.example.copilot.service;

import com.example.copilot.auth.CopilotAuthenticator;
import com.example.copilot.config.EnterpriseConfig;
import com.github.copilot.sdk.CopilotClient;
import com.github.copilot.sdk.CopilotSession;
import com.github.copilot.sdk.generated.AssistantMessageEvent;
import com.github.copilot.sdk.generated.SessionIdleEvent;
import com.github.copilot.sdk.generated.SessionUsageInfoEvent;
import com.github.copilot.sdk.json.CopilotClientOptions;
import com.github.copilot.sdk.json.MessageOptions;
import com.github.copilot.sdk.json.PermissionHandler;
import com.github.copilot.sdk.json.SessionConfig;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;

/**
 * ============================================================
 *  CopilotService
 *
 *  The primary service class for interacting with GitHub Copilot
 *  at Java runtime. Supports:
 *
 *    • STANDARD github.com accounts
 *    • Enterprise Managed Users (EMU) on github.com
 *    • GitHub Enterprise Cloud on ghe.com (Data Residency)
 *
 *  Features:
 *    • sendAndWait()          → blocking, full response
 *    • sendStreaming()        → real-time token streaming
 *    • sendWithMetrics()      → response + token usage stats
 *    • Multi-turn sessions    → session retains conversation context
 *    • Auto timeout           → configurable via copilot.properties
 *    • Enterprise auth        → pre-flight checks with clear guidance
 * ============================================================
 */
public class CopilotService implements AutoCloseable {

    // -------------------------------------------------------
    // Dependencies
    // -------------------------------------------------------
    private final EnterpriseConfig config;
    private final CopilotAuthenticator authenticator;

    // -------------------------------------------------------
    // SDK handles
    // -------------------------------------------------------
    private CopilotClient client;
    private CopilotSession session;

    // -------------------------------------------------------
    // State
    // -------------------------------------------------------
    private boolean started = false;

    // -------------------------------------------------------
    // Constructor
    // -------------------------------------------------------
    public CopilotService(EnterpriseConfig config) {
        this.config        = config;
        this.authenticator = new CopilotAuthenticator(config);
    }

    // -------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------

    /**
     * Runs pre-flight checks, starts the Copilot CLI process,
     * and creates a session. Must be called before sending messages.
     */
    public void start() throws Exception {
        // Step 1: Authentication pre-flight
        authenticator.preflight();

        // Step 2: Print config summary
        System.out.println("📋 Copilot Configuration:");
        System.out.println("─".repeat(50));
        System.out.println(config.summary());
        System.out.println("─".repeat(50) + "\n");

        // Step 3: Build client options
        //   For GHE accounts the CLI needs the enterprise host.
        //   The SDK propagates this via the COPILOT_GH_HOST env variable
        //   which the CLI reads at startup. We set a system property as
        //   a reminder — the user must also set the env var before running.
        CopilotClientOptions options = new CopilotClientOptions();

        if (config.getAccountType().name().equals("GHE") && !config.getEnterpriseHost().isBlank()) {
            // Guidance: COPILOT_GH_HOST must be set in the shell before running
            String host = config.getEnterpriseHost();
            System.out.println("ℹ️  GHE Mode: ensure COPILOT_GH_HOST=" + host + " is set in your environment.");
        }

        // Step 4: Start the Copilot CLI process
        System.out.println("🚀 Starting Copilot client...");
        client = new CopilotClient(options);
        client.start().get(config.getTimeoutSeconds(), TimeUnit.SECONDS);

        // Step 5: Create a session
        System.out.println("🔗 Creating Copilot session...");
        session = client.createSession(
            new SessionConfig()
                .setOnPermissionRequest(PermissionHandler.APPROVE_ALL)
                .setModel(config.getModel())
        ).get(config.getTimeoutSeconds(), TimeUnit.SECONDS);

        started = true;
        System.out.println("✅ Copilot session ready!\n");
    }

    // -------------------------------------------------------
    // Method 1 — sendAndWait (blocking, full response)
    // -------------------------------------------------------

    /**
     * Sends a prompt and blocks until Copilot returns the full response.
     *
     * Best for: batch jobs, simple Q&A, non-interactive workflows.
     *
     * @param prompt  The question or instruction.
     * @return        CopilotResponse containing the full answer.
     */
    public CopilotResponse sendAndWait(String prompt) throws Exception {
        validateSession();

        var sdkResponse = session.sendAndWait(
            new MessageOptions().setPrompt(prompt)
        ).get(config.getTimeoutSeconds(), TimeUnit.SECONDS);

        return new CopilotResponse(
            sdkResponse.getData().getContent(),
            0, 0, 0, 0  // Usage metrics not available on sendAndWait event
        );
    }

    // -------------------------------------------------------
    // Method 2 — sendStreaming (real-time token streaming)
    // -------------------------------------------------------

    /**
     * Sends a prompt and prints each token to stdout as it arrives.
     * Blocks until the stream is complete.
     *
     * Best for: interactive CLIs, live dashboards, chat UIs.
     *
     * @param prompt  The question or instruction.
     */
    public void sendStreaming(String prompt) throws Exception {
        validateSession();

        var done = new CompletableFuture<Void>();

        session.on(AssistantMessageEvent.class, msg -> {
            System.out.print(msg.getData().content());
            System.out.flush();
        });

        session.on(SessionIdleEvent.class, idle -> {
            System.out.println(); // end of stream — move to new line
            done.complete(null);
        });

        session.send(new MessageOptions().setPrompt(prompt))
               .get(config.getTimeoutSeconds(), TimeUnit.SECONDS);

        try {
            done.get(config.getTimeoutSeconds(), TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            System.err.println("\n[WARN] Stream timed out after " + config.getTimeoutSeconds() + "s");
        }
    }

    // -------------------------------------------------------
    // Method 3 — sendWithMetrics (response + token usage)
    // -------------------------------------------------------

    /**
     * Sends a prompt, returns the full response, AND captures token usage.
     *
     * Best for: cost monitoring, quota management, production audit trails.
     *
     * @param prompt  The question or instruction.
     * @return        CopilotResponse with content AND token usage populated.
     */
    public CopilotResponse sendWithMetrics(String prompt) throws Exception {
        validateSession();

        // Capture usage info from the async event
        AtomicReference<int[]> usageRef = new AtomicReference<>(new int[]{0, 0, 0, 0});

        session.on(SessionUsageInfoEvent.class, usage -> {
            var d = usage.getData();
            usageRef.set(new int[]{
                (int) d.currentTokens(),
                (int) d.currentTokens(),   // SDK provides currentTokens as the usage figure
                (int) d.tokenLimit(),
                (int) d.messagesLength()
            });
        });

        var sdkResponse = session.sendAndWait(
            new MessageOptions().setPrompt(prompt)
        ).get(config.getTimeoutSeconds(), TimeUnit.SECONDS);

        int[] usage = usageRef.get();
        return new CopilotResponse(
            sdkResponse.getData().getContent(),
            usage[0], usage[1], usage[2], usage[3]
        );
    }

    // -------------------------------------------------------
    // Method 4 — sendStreamingWithCallback (custom handler)
    // -------------------------------------------------------

    /**
     * Streams the response and calls your handler for each token chunk.
     * Useful when you want to route tokens to a UI component or log file
     * rather than printing to stdout.
     *
     * @param prompt          The question or instruction.
     * @param tokenHandler    Called for each streamed token chunk.
     */
    public void sendStreamingWithCallback(String prompt,
                                          java.util.function.Consumer<String> tokenHandler)
            throws Exception {
        validateSession();

        var done = new CompletableFuture<Void>();

        session.on(AssistantMessageEvent.class, msg -> {
            tokenHandler.accept(msg.getData().content());
        });

        session.on(SessionIdleEvent.class, idle -> done.complete(null));

        session.send(new MessageOptions().setPrompt(prompt))
               .get(config.getTimeoutSeconds(), TimeUnit.SECONDS);

        done.get(config.getTimeoutSeconds(), TimeUnit.SECONDS);
    }

    // -------------------------------------------------------
    // Validation
    // -------------------------------------------------------
    private void validateSession() {
        if (!started || session == null) {
            throw new IllegalStateException(
                "CopilotService not started. Call start() before sending messages."
            );
        }
    }

    // -------------------------------------------------------
    // Shutdown
    // -------------------------------------------------------
    @Override
    public void close() throws Exception {
        System.out.println("\n🛑 Shutting down Copilot client...");
        if (client != null) {
            client.close();
        }
        started = false;
    }
}
