package com.example.copilot.util;

/**
 * Shared console formatting utilities for the demo.
 */
public class ConsoleUtil {

    public static void printHeader(String title) {
        int width = 58;
        System.out.println("\n╔" + "═".repeat(width) + "╗");
        System.out.printf("║  %-" + (width - 2) + "s║%n", title);
        System.out.println("╚" + "═".repeat(width) + "╝\n");
    }

    public static void printDivider() {
        System.out.println("─".repeat(60));
    }

    public static void printUsageMetrics(com.example.copilot.service.CopilotResponse response) {
        if (response.getTokenLimit() > 0) {
            System.out.println("\n📊 Token Usage:");
            System.out.printf("   Used    : %,d / %,d tokens (%.1f%%)%n",
                response.getCurrentTokens(),
                response.getTokenLimit(),
                response.getTokenUsagePercent());
            System.out.printf("   Messages: %d in this session%n", response.getMessageCount());

            // Warn if approaching limits
            if (response.getTokenUsagePercent() > 80) {
                System.out.println("   ⚠️  Warning: Over 80% of token budget used!");
            }
        }
    }

    public static void pause(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
